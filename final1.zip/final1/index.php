<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SolanaBozos - Meme Token</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script src="assets/js/ajax.js" defer></script>
    <script src="assets/js/main.js" defer></script>
    <script src="assets/js/effects.js" defer></script>
</head>
<body>

    <!-- Header Section -->
    <?php include 'includes/header.php'; ?>

    <!-- Main Content Wrapper -->
    <div id="main-content">
        <!-- Default Section (Introduction) -->
        <?php include 'pages/about.php'; ?>
    </div>

    <!-- Footer Section -->
    <?php include 'includes/footer.php'; ?>

</body>
</html>
