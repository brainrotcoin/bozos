<!-- tokenomics.php - Tokenomics Section -->
<section id="tokenomics">
    <h1 class="glitch-text">Tokenomics</h1>
    <p>Total Supply: TBD (Bozos don’t plan, we ape!)</p>
    <p>No taxes, no team allocations. Just memes and mayhem.</p>
    <img src="assets/images/section_tokenomics.png" alt="Bozo Tokenomics" class="floating">
</section>
