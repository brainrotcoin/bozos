<!-- community.php - Community Section -->
<section id="community">
    <h1 class="glitch-text">Join the Bozo Community</h1>
    <p>Follow us on Twitter/X for daily unhinged memes, and join our Telegram for meme wars and degenerate challenges.</p>
    <img src="assets/images/section_community.png" alt="Bozo Community" class="floating">
</section>
