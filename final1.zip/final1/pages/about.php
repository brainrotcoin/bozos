<!-- about.php - Updated About Section -->
<section id="about" class="neon-section">
    <h1 class="glitch-text">Who TF Are the Bozos?</h1>
    <p class="neon-text">SolanaBozos is the wildest meme token on Solana. No tax, no utility, just 100% pure degen chaos driven by the community.</p>
    <div class="section-image-container">
        <img src="assets/images/section_about.png" alt="Bozo About" class="neon-frame floating">
    </div>
</section>
