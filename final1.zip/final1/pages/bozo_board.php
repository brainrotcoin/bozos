<!-- bozo_board.php - Leaderboard Section -->
<section id="bozo_board">
    <h1 class="glitch-text">Bozo Board</h1>
    <p>Top traders, biggest losers, and the most legendary degens. Who will be crowned King Bozo?</p>
    <img src="assets/images/section_bozo_board.png" alt="Bozo Board" class="floating">
</section>
