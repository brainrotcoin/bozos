<!-- live_feed.php - Live Meme Feed Section -->
<section id="live_feed">
    <h1 class="glitch-text">Live Meme Feed</h1>
    <p>Real-time trades by the biggest Bozos around the world. Expect YOLOs, rugs, and diamond hands!</p>
    <img src="assets/images/section_live_feed.png" alt="Bozo Live Feed" class="floating">
</section>
