<?php
$contract = "YourContractAddressHere";
echo $contract;
?>
