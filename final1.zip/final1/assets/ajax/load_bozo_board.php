<!-- load_bozo_board.php -->
<?php include '../../pages/bozo_board.php'; ?>
