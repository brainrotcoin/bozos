<!-- load_community.php -->
<?php include '../../pages/community.php'; ?>
