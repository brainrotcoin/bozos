<!-- load_how_to_buy.php -->
<?php include '../../pages/how_to_buy.php'; ?>
