<!-- load_live_feed.php -->
<?php include '../../pages/live_feed.php'; ?>
