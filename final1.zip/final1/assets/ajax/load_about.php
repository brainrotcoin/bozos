<!-- load_about.php -->
<?php include '../../pages/about.php'; ?>
