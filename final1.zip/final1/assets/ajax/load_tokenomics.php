<!-- load_tokenomics.php -->
<?php include '../../pages/tokenomics.php'; ?>
