// ajax.js - Handles Dynamic Content Loading

function loadSection(section) {
    fetch(`assets/ajax/load_${section}.php`)
        .then((response) => response.text())
        .then((data) => {
            document.getElementById("main-content").innerHTML = data;
        })
        .catch((error) => console.error("Error loading section:", error));
}

// Default section load
document.addEventListener("DOMContentLoaded", function () {
    loadSection("about");
});
