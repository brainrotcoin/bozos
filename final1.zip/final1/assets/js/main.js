// main.js - Handles UI Interactivity & Effects

document.addEventListener("DOMContentLoaded", function () {
    console.log("SolanaBozos Loaded!");

    // Smooth Scroll for Internal Links
    document.querySelectorAll("nav a").forEach((link) => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            const section = this.getAttribute("data-section");
            loadSection(section);
        });
    });

    // Hover Effect on Buttons
    document.querySelectorAll(".glow-hover").forEach((button) => {
        button.addEventListener("mouseenter", function () {
            this.classList.add("glow-effect");
        });
        button.addEventListener("mouseleave", function () {
            this.classList.remove("glow-effect");
        });
    });
});
