<?php
// ajax.php - Handles AJAX Requests for Dynamic Content Loading

if (isset($_GET['section'])) {
    $section = $_GET['section'];

    switch ($section) {
        case 'about':
            include 'assets/ajax/load_about.php';
            break;

        case 'tokenomics':
            include 'assets/ajax/load_tokenomics.php';
            break;

        case 'live_feed':
            include 'assets/ajax/load_live_feed.php';
            break;

        case 'bozo_board':
            include 'assets/ajax/load_bozo_board.php';
            break;

        case 'how_to_buy':
            include 'assets/ajax/load_how_to_buy.php';
            break;

        case 'community':
            include 'assets/ajax/load_community.php';
            break;

        default:
            echo "<h1 class='glitch-text'>404 - Section Not Found!</h1>";
            break;
    }
} else {
    echo "<h1 class='glitch-text'>Invalid Request!</h1>";
}
?>
