<!-- config.php - Global Configuration -->
<?php
define("SITE_NAME", "SolanaBozos");
define("SITE_URL", "https://solanabozos.com");

// Future Expansion: Add API keys, database details, etc.
?>
