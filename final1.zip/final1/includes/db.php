<!-- db.php - Database Connection (Optional for Future Use) -->
<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "solanabozos";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
