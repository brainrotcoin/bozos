<!-- footer.php - Footer Section -->
<footer>
    <p>&copy; <?php echo date('Y'); ?> SolanaBozos. All rights degenerated.</p>
</footer>
