<!-- nav.php - Standalone Navigation -->
<nav>
    <a href="#" data-section="about">Introduction</a>
    <a href="#" data-section="tokenomics">Tokenomics</a>
    <a href="#" data-section="live_feed">Live Meme Feed</a>
    <a href="#" data-section="bozo_board">Bozo Board</a>
    <a href="#" data-section="how_to_buy">How to Buy</a>
    <a href="#" data-section="community">Community</a>
</nav>
